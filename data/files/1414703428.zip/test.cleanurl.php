<?php
require("class.cleanurl.php");

$clean = new CleanURL;
$clean->parseURL();
$clean->setRelative('relativeslash'); //relativeslash is variable name
$clean->setParts('id','page');
echo 'result query string<br>';
echo 'id = '.$id . '<br>';
echo 'page = ' . $page . '<br>';

?>
<br>
Example Clean URL usage:  <br>
<a href="<?=$relativeslash?><?=CleanURL::makeClean('test.cleanurl.php?id=120&page=2');?>">Link 1</a>