<body style="margin: 0;">
	<img class="capture-image" src="image.php">	
</body>
